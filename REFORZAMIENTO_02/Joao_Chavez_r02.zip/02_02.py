var_int = 52

resultado = var_int * 10 + 10

var_float = float(resultado)

print(var_float)