exp = 6
var1 = 2

var1_elevada = pow(var1,exp)

var1_por2 = var1 * 2

resultado = var1_elevada - var1_por2

print(resultado)
