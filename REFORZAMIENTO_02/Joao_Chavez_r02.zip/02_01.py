
nombre = "Joao Chavez"

mi_saludo = "¡Hi {}!".format(nombre)

print(mi_saludo)