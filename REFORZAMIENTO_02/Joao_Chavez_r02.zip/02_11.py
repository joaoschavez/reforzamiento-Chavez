varint = 10

resultado1 = varint ** 5 / 10

tipo_de_dato1 = type(resultado1)

modulo3 = resultado1 % 3

print("El tipo de dato del resultado es {} y el modulo 3 del resultado es {}".format(tipo_de_dato1, modulo3))