
float1 = 3.14
float2 = 5.45
float3 = 9.99
float4 = 41.80
float5 = 33.33

media_float = (float1 + float2 + float3 + float4 + float5) / 5

print(media_float)
