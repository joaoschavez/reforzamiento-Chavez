sueldo = 3600

if sueldo % 2 == 0:
    print("El sueldo que ganas es un número par")

else:
    print("El sueldo que ganas es un número impar")