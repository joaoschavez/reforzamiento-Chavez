list1 = [2, 5, 3.14, 5.66, "Joao", "Chavez", True, False]

list2 = [2, 4, 6, 8, 10, 12, 14]


sumar_listas = list1 + list2

print(sumar_listas)

#Al sumar las listas los datos de las listas de juntan considerando primero los datos de la lista1 y agregando al final
#los datos de la lista 2