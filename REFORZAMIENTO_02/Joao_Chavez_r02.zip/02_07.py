int1 = 50
int2 = -35
int3 = 120

mod1 = int1 % 3
mod2 = int2 % 5
mod3 = int3 % 7

suma_modulos = mod1 + mod2 + mod3

print(suma_modulos)