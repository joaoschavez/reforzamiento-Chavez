diccionario = {
    "nombre" : "Joao",
    "carrera" : "Contabilidad",
    "edad" : 27,
    "año de nacimiento" : 1996
}


print(diccionario)