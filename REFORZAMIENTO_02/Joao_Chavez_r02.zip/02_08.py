list1 = ["Joao", "Chavez", 27, 1.72]
list2 = []

if not list2:
    print("la lista está vacía")

else:
    print("Lista tiene datos")


if not list1:
    print("Lista tiene datos")

else:
    print("La lista está vacía")