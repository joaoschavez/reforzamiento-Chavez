#FORMULA DE VOLUMEN DE UNA ESFERA
# V = 4/3*PI*r**3

num = 4/3
pi = 3.14
r = 6

vol_esfera= num * pi * (r**3)

print(vol_esfera)
