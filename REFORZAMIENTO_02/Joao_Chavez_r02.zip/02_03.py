var_str = "32"
var_int = 33

resultado = int(var_str) + var_int

print(resultado)